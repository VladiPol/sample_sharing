####### audit log config

auditctl -w /share -p wra -k share
auditctl -l