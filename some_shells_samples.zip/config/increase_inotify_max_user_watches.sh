#!/bin/bash
# https://jira.teambank.de/jira/browse/DATASCI-3146
# Prüfe den aktuellen Wert von fs.inotify.max_user_watches
current_value=$(cat /proc/sys/fs/inotify/max_user_watches)

# Wenn der aktuelle Wert nicht 16384 ist, füge den Wert in die /etc/sysctl.conf ein
if [ "$current_value" != "16384" ]; then

  # Lösche die Zeile, falls sie bereits vorhanden ist
  if grep -q "fs.inotify.max_user_watches" /etc/sysctl.conf; then
    sed -i "/fs.inotify.max_user_watches/d" /etc/sysctl.conf
  fi

  # Füge die Zeile hinzu
  echo "fs.inotify.max_user_watches=16384" >> /etc/sysctl.conf
fi

# Führe sysctl -p aus, um die Änderungen zu übernehmen
sysctl -p
