#!/bin/bash

# This script installs needed AZURE CLI tools and backups the /misc/data folder to the cloud
# In the cloud this backup is used to restore the current use-case folder
# 
# The followong folders should exist and have restricted access rights:
# "/opt/migration"

# mein letztes Scirpt für die TeamBank :) #Raphael Lorenz 21.06.23

# Name der Log-Datei
LOGFILE=/var/log/cloud_sync.log

# Add locally installed executables to path
export PATH="/opt/migration/:$PATH"


log () {
    # $1 LOGLEVEL
    # $2 MESSAGE
    echo "*** $(date "+%Y-%m-%d %X") [$1] $2" | tee -a $LOGFILE
}

# Start
log_start()
{
 echo " " | tee -a $LOGFILE
 echo "######################################################################################################################" | tee -a $LOGFILE
 echo "Cloud Sync Skript-Start am `date +'%d.%m.%Y %H:%M'`" | tee -a $LOGFILE
 echo "######################################################################################################################" | tee -a $LOGFILE
 echo " " | tee -a $LOGFILE
}

# End
log_end()
{
 echo " " | tee -a $LOGFILE
 echo "######################################################################################################################" | tee -a $LOGFILE
 echo "Cloud Sync Skript-End am `date +'%d.%m.%Y %H:%M'`" | tee -a $LOGFILE
 echo "######################################################################################################################" | tee -a $LOGFILE
 echo " " | tee -a $LOGFILE
}


install_azure_tools () {
    conda activate azure
    if [ $? -ne 0 ]; then
        log "INFO" "Creating azure conda env..."
        conda create -n azure python=3.9.* -y
    fi
    conda activate azure

    az -v
    if [ $? -ne 0 ]; then
        log "INFO" "Installing azure CLI..."
        pip install azure-cli
    fi

    ## Install azcopy
    local AZCOPY_DEST="/opt/migration/azcopy"
    if [ -f "${AZCOPY_DEST}" ]; then
        log "INFO" "azcopy already in destination. Skipping."
    else
        log "INFO" "azcopy not installed, installing..."

        local AZCOPY_PATH="./azcopy-linux64"

        if [ -f "${AZCOPY_DEST}" ]; then
            log "ERROR" "azcopy already in destination. Skipping."
        else
            curl -fSsL https://nexus.prod.oscp.easycredit.intern/repository/analytics-hosted-public-raw/azcopy/azcopy_linux_amd64_10.13.0 --output "${AZCOPY_PATH}"

            log "INFO" "making azcopy executable"
            chmod 755 ${AZCOPY_PATH}

            log "INFO" "Moving azcopy to ${AZCOPY_DEST}"
            mv ${AZCOPY_PATH} ${AZCOPY_DEST}
        fi

        local AZCOPY_TEST=$(azcopy -v)
        if [ $? -eq 0 ]; then
            log "INFO" "${AZCOPY_TEST} installed"
        else
            log "ERROR" "something went wrong installing azcopy"
            exit 1
        fi
    fi

    # Install jq
    jq --version
    if [ $? -eq 0 ]; then
        local JQ_TEST=$(jq --version)
        log "INFO" "${JQ_TEST} is installed"
    else
        log "INFO" "Installing jq"
        local JQ_PATH="./jq-linux64"
        local JQ_DEST="/opt/migration/jq"

        curl -fSsL https://nexus.prod.oscp.easycredit.intern/repository/analytics-hosted-public-raw/jq/jq-linux64_1.6 --output ${JQ_PATH}

        log "INFO" "making jq executable"
        chmod 755 ${JQ_PATH}

        log "INFO" "copying jq to ${JQ_DEST}"
        mv ${JQ_PATH} ${JQ_DEST}

        jq --version
        if [ $? -eq 0 ]; then
          local JQ_TEST=$(jq --version)
          log "INFO" "${JQ_TEST} is installed"
        else
          log "ERROR" "something went wrong installing jq"
          exit 1
        fi
    fi

}

# Check for an upload error of azcopy after backup or recovery.
check_upload_error () {
    set +x
    local OUTPUT_ARRAY=$1
    local CONTAINER=$2
    local SOURCE=$3
    local INIT_JOB_MSG=$(echo ${OUTPUT_ARRAY} | jq 'select(.MessageType=="Init")') # Init message from azcopy provides information abozt the job
    local END_OF_JOB_MSG=$(echo ${OUTPUT_ARRAY} | jq 'select(.MessageType=="EndOfJob")') # end of job message from azcopy indicates that the job at least ran throuhg
    local ERROR_MSG=$(echo ${OUTPUT_ARRAY} | jq 'select(.MessageType=="Error")') # Error message in azcopy output, needs to be investigated below
    set -x
    local INFO=""
    local JOB_ID=""

    if [ -n "${INIT_JOB_MSG}" ]; then
        local MSG_CONTENT=$(echo ${INIT_JOB_MSG} | jq --raw-output '.MessageContent')
        JOB_ID=$(echo $MSG_CONTENT} | jq --raw-output '.JobID')
        local AZCOPY_LOGFILE_LOCATION=$(echo $MSG_CONTENT} | jq --raw-output '.LogFileLocation')
        INFO=$(echo "INFO: Backup Job ID of ${CONTAINER}:  ${JOB_ID} ; ${AZCOPY_LOGFILE_LOCATION}")
    fi

    if [ -n "${ERROR_MSG}" ]; then

        local MSG_CONTENT=$(echo ${ERROR_MSG} | jq --raw-output '.MessageContent')
        case "$MSG_CONTENT" in
            *AuthorizationResourceTypeMismatch*)
              log "ERROR" "Mismatch between the ressource and the authorization scope when copying container ${CONTAINER}; $INFO"
              return 1
            ;;
            *"Login Credentials missing"*)
              log "ERROR" "No SAS token or wrong format for account ${SOURCE}; $INFO"
              return 1
            ;;
            *)
              log "ERROR" "Unkown error copying container ${CONTAINER}; $INFO"
              return 1
            ;;
         esac

    fi

    if [ -n "${END_OF_JOB_MSG}" ]; then

        local MSG_CONTENT=$(echo ${END_OF_JOB_MSG} | jq --raw-output '.MessageContent') # most relevant field of the end_of_job_msg array.

        local JOB_STATUS=$(echo ${MSG_CONTENT} | jq --raw-output '.JobStatus')
        local JOB_TRANSFERS=$(echo ${MSG_CONTENT} | jq --raw-output '.TotalTransfers')
        local JOB_ERROR=$(echo ${MSG_CONTENT} | jq --raw-output '.ErrorMsg')
        local JOB_COMPLETED=$(echo ${MSG_CONTENT} | jq --raw-output '.TransfersCompleted')
        local FAILED_TRANSFERS_ERROR_CODE=$(echo ${MSG_CONTENT} | jq --raw-output '.FailedTransfers[0].ErrorCode')

        if [ "${JOB_STATUS}" = "Completed" ]; then
            log "INFO" "Completed copy from ${CONTAINER}@${SOURCE}. Transfered ${JOB_COMPLETED}/${JOB_TRANSFERS} blobs (JOB-ID=${JOB_ID})"
            return 0
        else
            # There are too much different types of azcopy errors too capute each individually. We try to give as much info in the error as possible.
            log "ERROR" "Error in copy from ${CONTAINER}@${SOURCE}. Job is ${JOB_STATUS}. ERR: ${JOB_ERROR:-NONE}. ERRCODE: ${FAILED_TRANSFERS_ERROR_CODE:-NONE}; $INFO"
            return 1
        fi

    fi

    log "ERROR" "Unkown error or response format from azcopy. Response: ${OUTPUT_ARRAY}; $INFO"
    return 1
}

upload_to_cloud () {
  local container="stcapadls${STAGE}001"

  set +x
  local AZURE_PWD_FILE="/opt/migration/azurePwd.json"
  local dest_sas=$(cat "$AZURE_PWD_FILE" | jq --raw-output ".${STAGE}.azureToken" 2> /dev/null)
  if [ -z "$dest_sas" ]; then
    log "ERROR" "No Azure STS Token provided for container '${container}', please check '$AZURE_PWD_FILE' file"
    exit 1
  fi

  log "INFO" "Uploading to cloud storage '${container}'"
  local OUTPUT=$(azcopy copy --recursive=true --output-type json --cap-mbps 150 --log-level ERROR "${USECASEFOLDERPATH}/*" "https://stcapadls${STAGE}001.blob.core.windows.net/$USECASENAME/?$dest_sas")
  local RETURN_MSG=$(check_upload_error "${OUTPUT}" "${container}" "${USECASEFOLDERPATH}/*")
  log "INFO" "${RETURN_MSG}"
  set -x
  return 0
}

#Start
STAGE=$1
USECASENAME=$2
DATAPATH="/misc/data/usecases/"
USECASEFOLDERPATH="${DATAPATH}${USECASENAME}"

  log_start
  


# Check if usercase has been migrated
if [[ -f "$USECASEFOLDERPATH/.sync" ]]; then
    log "ERROR" "UseCase wurde bereits migriert!"
    exit 1
fi


  # init anaconda
  eval "$(conda shell.bash hook)"

  install_azure_tools
  
  upload_to_cloud

  # Creates a file after successful sync and look them for normal users
cd $USECASEFOLDERPATH
 touch .sync
 chmod 0700 $USECASEFOLDERPATH
  log_end

exit 0
