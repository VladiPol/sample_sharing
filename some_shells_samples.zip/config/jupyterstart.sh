#!/bin/bash

/opt/anaconda/miniconda/bin/jupyterhub -f /etc/jupyterhub/jupyterhub_config.py >> /misc/remotelog/jupyterhub/jupyterhub.log 2>&1
