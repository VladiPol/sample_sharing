# File to set java home path for all users

export JAVA_HOME="/usr/lib/jvm/java-1.8.0-openjdk/"
export REQUESTS_CA_BUNDLE="/etc/ssl/certs/ca-bundle.crt"

if [ "$(whoami)" != "root" ]; then
    umask u=rwx,g=rwx,o=rwx
  else
    umask 0022
fi
