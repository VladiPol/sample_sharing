# File to set oracle home path for all users

export ORACLE_BASE=/opt/treiber/oracle
export ORACLE_HOME=$ORACLE_BASE/product/19.0.0/dbhome_1
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$ORACLE_HOME/lib:/lib:/usr/lib
export TNS_ADMIN=/opt/treiber/oracle/tns_admin
export PATH=.:$PATH:$HOME/.local/bin:$HOME/bin:$ORACLE_HOME/OPatch:$ORACLE_HOME/bin