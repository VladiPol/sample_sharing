#!/bin/bash
#Author: Lukas Rust
#Jupyterhub can leave a stale proxy behind after shutting down
#This Script makes sure jupyterhub is gone completly

sleep 2

jupyter_pid_1=$(ps aux | grep "/etc/jupyterhub/jupyterstart.sh" | grep -v grep | awk '{print $2}')
jupyter_pid_2=$(ps aux | grep "/opt/anaconda/miniconda/bin/jupyterhub" | grep -v grep | awk '{print $2}')
proxy_pid=$(ps aux | grep "configurable-http-proxy" |grep -v grep |awk '{print $2}')

if [ -z "$jupyter_pid_1" ] && [ -z "$jupyter_pid_2" ] && [ -z "$proxy_pid" ]; then
  exit 0
fi

echo "kill jupyterhub"

kill -9 $jupyter_pid_1
kill -9 $jupyter_pid_2
kill -9 $proxy_pid

jupyter_pid_1=$(ps aux | grep "/etc/jupyterhub/jupyterstart.sh" | grep -v grep | awk '{print $2}')
jupyter_pid_2=$(ps aux | grep "/opt/anaconda/miniconda/bin/jupyterhub" | grep -v grep | awk '{print $2}')
proxy_pid=$(ps aux | grep "configurable-http-proxy" |grep -v grep |awk '{print $2}')

if [ -z "$jupyter_pid_1" ] && [ -z "$jupyter_pid_2" ] && [ -z "$proxy_pid" ]; then
  exit 0
fi

exit 1

